﻿using ABC_Retail.Azure;
using ABC_Retail.Models;
using ABC_Retail.Services;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container
builder.Services.AddControllersWithViews();

builder.Services.AddSingleton<CustomerService>(sp =>
{
    var config = sp.GetRequiredService<IConfiguration>();
    return new CustomerService(config); 

// Other services
builder.Services.AddSingleton<ProductService>(sp =>
{
    var config = sp.GetRequiredService<IConfiguration>();
    return new ProductService(
        config["AzureStorage:ConnectionString"],
        config["AzureStorage:ProductTable"]
    );
});

builder.Services.AddSingleton<OrderService>(sp =>
{
    var config = sp.GetRequiredService<IConfiguration>();
    return new OrderService(
        config["AzureStorage:ConnectionString"],
        config["AzureStorage:OrderTable"],
        config["AzureStorage:OrderQueue"]
    );
});

builder.Services.AddSingleton<QueueService>(sp =>
{
    var config = sp.GetRequiredService<IConfiguration>();
    return new QueueService(
        config["AzureStorage:ConnectionString"],
        config["AzureStorage:OrderQueue"]
    );
});

builder.Services.AddSingleton<FileShareService>(sp =>
{
    var config = sp.GetRequiredService<IConfiguration>();
    return new FileShareService(
        config["AzureStorage:ConnectionString"],
        config["AzureStorage:FileShare"]
    );
});

builder.Services.AddSingleton<BlobStorageService>(sp =>
{
    var config = sp.GetRequiredService<IConfiguration>();
    return new BlobStorageService(config);
});

// Azure Functions API
builder.Services.AddSingleton<FunctionApiService>();

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseAuthorization();

// MVC Route
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}"
);

app.Run();
