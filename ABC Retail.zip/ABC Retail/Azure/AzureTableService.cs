﻿using Azure;
using Azure.Data.Tables;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ABC_Retail.Azure
{
    public class AzureTableService<T> where T : class, ITableEntity, new()
    {
        private readonly TableClient _tableClient;

        public AzureTableService(string connectionString, string tableName = "Orders")
        {
            _tableClient = new TableClient(connectionString, tableName = "Orders");
            _tableClient.CreateIfNotExists();
        }

        public async Task AddEntityAsync(T entity)
        {
            if (string.IsNullOrEmpty(entity.RowKey))
                entity.RowKey = Guid.NewGuid().ToString();

            await _tableClient.AddEntityAsync(entity);
        }

        public async Task<List<T>> GetAllEntitiesAsync()
        {
            var entities = new List<T>();
            await foreach (var entity in _tableClient.QueryAsync<T>())
            {
                entities.Add(entity);
            }
            return entities;
        }

        public async Task DeleteEntityAsync(string partitionKey, string rowKey)
        {
            await _tableClient.DeleteEntityAsync(partitionKey, rowKey);
        }
    }
}
