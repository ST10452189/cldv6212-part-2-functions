﻿using ABC_Retail.Models;
using Azure.Data.Tables;
using Azure.Storage.Queues;
using System;
using System.Collections.Generic;
using System.Text.Json;
using System.Threading.Tasks;

namespace ABC_Retail.Azure
{
    public class OrderService
    {
        private readonly TableClient _tableClient;
        private readonly QueueClient _queueClient;

        public OrderService(string connectionString, string tableName = "Orders", string queueName = "ordersqueue")
        {
            _tableClient = new TableClient(connectionString, tableName = "Orders");
            _tableClient.CreateIfNotExists();

            _queueClient = new QueueClient(connectionString, queueName = "ordersqueue");
            _queueClient.CreateIfNotExists();
        }

        public async Task AddOrderAsync(Order order)
        {
            if (string.IsNullOrEmpty(order.PartitionKey)) order.PartitionKey = "ORDER";
            if (string.IsNullOrEmpty(order.RowKey)) order.RowKey = Guid.NewGuid().ToString();

            await _tableClient.AddEntityAsync(order);

            var queueMessage = new
            {
                Type = "Transaction",
                RowKey = order.RowKey,
                CustomerId = order.CustomerId,
                ProductId = order.ProductId,
                Quantity = order.Quantity,
                Timestamp = DateTime.UtcNow
            };

            string messageJson = JsonSerializer.Serialize(queueMessage);
            await _queueClient.SendMessageAsync(
                Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(messageJson))
            );
        }

        public async Task<List<Order>> GetAllOrdersAsync()
        {
            var orders = new List<Order>();
            await foreach (var entity in _tableClient.QueryAsync<Order>())
            {
                orders.Add(entity);
            }
            return orders;
        }

        public async Task DeleteOrderAsync(string rowKey)
        {
            await _tableClient.DeleteEntityAsync("ORDER", rowKey);
        }
    }
}
