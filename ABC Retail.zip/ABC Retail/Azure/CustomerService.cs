﻿using System.Text;
using System.Text.Json;
using ABC_Retail.Models;

public class CustomerService
{
    private readonly string _functionBaseUrl;
    private readonly string _functionKey;
    private readonly HttpClient _httpClient;

    public CustomerService(IConfiguration config)
    {
        _functionBaseUrl = config["AzureFunctions:BaseUrl"]
                           ?? throw new ArgumentException("Function BaseUrl is required.");
        _functionKey = config["AzureFunctions:FunctionKey"]
                       ?? throw new ArgumentException("Function Key is required.");
        _httpClient = new HttpClient();
    }

    private string BuildUrl(string route) =>
        $"{_functionBaseUrl.TrimEnd('/')}/{route}?code={_functionKey}";

    public async Task AddCustomerAsync(Customer customer)
    {
        if (string.IsNullOrEmpty(customer.PartitionKey))
            customer.PartitionKey = "Customer";
        if (string.IsNullOrEmpty(customer.RowKey))
            customer.RowKey = Guid.NewGuid().ToString();

        var url = BuildUrl("customer");
        var json = JsonSerializer.Serialize(customer);
        var content = new StringContent(json, Encoding.UTF8, "application/json");

        var response = await _httpClient.PostAsync(url, content);
        response.EnsureSuccessStatusCode();
    }

    public async Task<List<Customer>> GetAllCustomersAsync()
    {
        var customers = await _httpClient.GetFromJsonAsync<List<Customer>>(BuildUrl("customer"));
        return customers ?? new List<Customer>();
    }

    public async Task DeleteCustomerAsync(string rowKey)
    {
        var response = await _httpClient.DeleteAsync(BuildUrl($"customer/{rowKey}"));
        response.EnsureSuccessStatusCode();
    }
}
