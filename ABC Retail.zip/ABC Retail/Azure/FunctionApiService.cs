﻿using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace ABC_Retail.Services
{
    public class FunctionApiService
    {
        private readonly HttpClient _client;

        public FunctionApiService(IHttpClientFactory factory)
        {
            _client = factory.CreateClient("AzureFunctions");
        }

        public async Task<string> UploadFileAsync(string fileName, string base64Content)
        {
            var payload = new
            {
                FileName = fileName,
                FileContent = base64Content
            };

            var json = JsonSerializer.Serialize(payload);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            var response = await _client.PostAsync("upload", content);
            return await response.Content.ReadAsStringAsync();
        }

    }
}
