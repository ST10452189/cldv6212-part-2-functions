﻿using Azure;
using Azure.Storage.Files.Shares;
using System;
using System.IO;
using System.Threading.Tasks;

namespace ABC_Retail.Azure
{
    public class FileShareService
    {
        private readonly ShareClient _shareClient;

        public FileShareService(string connectionString, string shareName)
        {
            if (string.IsNullOrWhiteSpace(connectionString))
                throw new ArgumentException("Connection string is required.", nameof(connectionString));

            if (string.IsNullOrWhiteSpace(shareName))
                shareName = "theosfiles";

            _shareClient = new ShareClient(connectionString, shareName);
            _shareClient.CreateIfNotExists();
        }

        public async Task UploadFileAsync(string fileName, Stream fileStream)
        {
            if (string.IsNullOrWhiteSpace(fileName))
                throw new ArgumentException("File name is required.", nameof(fileName));

            if (fileStream == null || fileStream.Length == 0)
                throw new ArgumentException("File stream is empty.", nameof(fileStream));

            var directory = _shareClient.GetRootDirectoryClient();
            var fileClient = directory.GetFileClient(fileName);

            await fileClient.CreateAsync(fileStream.Length);
            await fileClient.UploadRangeAsync(new HttpRange(0, fileStream.Length), fileStream);
        }

        public async Task<Stream> DownloadFileAsync(string fileName)
        {
            if (string.IsNullOrWhiteSpace(fileName))
                throw new ArgumentException("File name is required.", nameof(fileName));

            var directory = _shareClient.GetRootDirectoryClient();
            var fileClient = directory.GetFileClient(fileName);

            if (!await fileClient.ExistsAsync())
                throw new FileNotFoundException($"File '{fileName}' does not exist in the File Share.");

            var downloadInfo = await fileClient.DownloadAsync();
            var memoryStream = new MemoryStream();
            await downloadInfo.Value.Content.CopyToAsync(memoryStream);
            memoryStream.Position = 0;
            return memoryStream;
        }
    }
}
