﻿using ABC_Retail.Models;
using Azure;
using Azure.Data.Tables;

namespace ABC_Retail.Azure
{
    public class ProductService
    {
        private readonly TableClient _tableClient;

        public ProductService(string connectionString, string tableName = "Products")
        {
            _tableClient = new TableClient(connectionString, tableName = "Products");
            _tableClient.CreateIfNotExists();
        }

        public async Task AddProductAsync(Product product)
        {
            await _tableClient.AddEntityAsync(product);
        }

        public async Task<List<Product>> GetAllProductsAsync()
        {
            var products = new List<Product>();
            await foreach (var entity in _tableClient.QueryAsync<Product>())
            {
                products.Add(entity);
            }
            return products;
        }

        public async Task DeleteProductAsync(string rowKey)
        {
            await _tableClient.DeleteEntityAsync("PRODUCT", rowKey);
        }
    }
}
