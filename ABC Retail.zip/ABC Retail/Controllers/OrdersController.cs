﻿using Microsoft.AspNetCore.Mvc;
using ABC_Retail.Models;
using ABC_Retail.Azure;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Linq;
using System;
using System.Threading.Tasks;

namespace ABC_Retail.Controllers
{
    public class OrdersController : Controller
    {
        private readonly OrderService _orderService;
        private readonly ProductService _productService;
        private readonly CustomerService _customerService;

        public OrdersController(OrderService orderService, ProductService productService, CustomerService customerService)
        {
            _orderService = orderService;
            _productService = productService;
            _customerService = customerService;
        }

        // GET: Orders
        public async Task<IActionResult> Index()
        {
            var orders = await _orderService.GetAllOrdersAsync();
            return View(orders);
        }

        // GET: Create Order
        public async Task<IActionResult> Create()
        {
            ViewBag.Products = new SelectList(await _productService.GetAllProductsAsync(), "RowKey", "Name");
            ViewBag.Customers = new SelectList(await _customerService.GetAllCustomersAsync(), "RowKey", "FirstName");
            return View();
        }

        // POST: Create Order
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Order order)
        {
            if (string.IsNullOrEmpty(order.RowKey))
                order.RowKey = Guid.NewGuid().ToString();

            if (!ModelState.IsValid)
            {
                ViewBag.Products = new SelectList(await _productService.GetAllProductsAsync(), "RowKey", "Name");
                ViewBag.Customers = new SelectList(await _customerService.GetAllCustomersAsync(), "RowKey", "FirstName");

                var errors = string.Join("; ", ModelState.Values
                                    .SelectMany(v => v.Errors)
                                    .Select(e => e.ErrorMessage));
                TempData["ErrorMessage"] = $"ModelState invalid: {errors}";
                return View(order);
            }

            try
            {
                order.PartitionKey = "ORDER";
                await _orderService.AddOrderAsync(order);

                TempData["Message"] = "Order created successfully!";
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = $"Error creating order: {ex.Message}";
                ViewBag.Products = new SelectList(await _productService.GetAllProductsAsync(), "RowKey", "Name");
                ViewBag.Customers = new SelectList(await _customerService.GetAllCustomersAsync(), "RowKey", "FirstName");
                return View(order);
            }
        }

        // POST: Delete Order
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(string rowKey)
        {
            if (string.IsNullOrEmpty(rowKey))
            {
                TempData["ErrorMessage"] = "Invalid order ID.";
                return RedirectToAction(nameof(Index));
            }

            try
            {
                await _orderService.DeleteOrderAsync(rowKey);
                TempData["Message"] = "Order deleted successfully!";
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = $"Error deleting order: {ex.Message}";
            }

            return RedirectToAction(nameof(Index));
        }
    }
}
