﻿using Microsoft.AspNetCore.Mvc;
using ABC_Retail.Models;
using ABC_Retail.Azure;

namespace ABC_Retail.Controllers
{
    public class CustomersController : Controller
    {
        private readonly CustomerService _customerService;

        public CustomersController(CustomerService customerService)
        {
            _customerService = customerService;
        }

        // Display all customers
        public async Task<IActionResult> Index()
        {
            var customers = await _customerService.GetAllCustomersAsync();
            return View(customers);
        }

        // Show create form
        public IActionResult Create()
        {
            return View(new Customer());
        }

        [HttpPost]
        public async Task<IActionResult> Add(Customer customer)
        {
            if (!ModelState.IsValid)
                return View("Create", customer);

            try
            {
                // Set PartitionKey and RowKey here too just in case
                if (string.IsNullOrEmpty(customer.PartitionKey))
                    customer.PartitionKey = "Customer";
                if (string.IsNullOrEmpty(customer.RowKey))
                    customer.RowKey = Guid.NewGuid().ToString();

                await _customerService.AddCustomerAsync(customer);
                TempData["Message"] = "Customer added successfully!";
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                TempData["Message"] = $"Error adding customer: {ex.Message}";
                return View("Create", customer);
            }
        }


        // Delete a customer
        [HttpPost]
        public async Task<IActionResult> Delete(string rowKey)
        {
            if (!string.IsNullOrEmpty(rowKey))
            {
                try
                {
                    await _customerService.DeleteCustomerAsync(rowKey);
                    TempData["Message"] = "Customer deleted successfully!";
                }
                catch (Exception ex)
                {
                    TempData["Message"] = $"Error deleting customer: {ex.Message}";
                }
            }
            return RedirectToAction(nameof(Index));
        }
    }
}
