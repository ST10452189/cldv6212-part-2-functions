﻿using Microsoft.AspNetCore.Mvc;
using ABC_Retail.Models;
using ABC_Retail.Azure;
using ABC_Retail.Services;

namespace ABC_Retail.Controllers
{
    public class ProductsController : Controller
    {
        private readonly ProductService _productService;
        private readonly BlobStorageService _blobService;

        public ProductsController(ProductService productService, BlobStorageService blobService)
        {
            _productService = productService;
            _blobService = blobService;
        }

        // GET: Products
        public async Task<IActionResult> Index()
        {
            var products = await _productService.GetAllProductsAsync();
            return View(products);
        }

        // GET: Products/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Products/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Product product, IFormFile imageFile)
        {
            if (!ModelState.IsValid)
                return View(product);

            try
            {
                product.PartitionKey = "PRODUCT";
                product.RowKey = Guid.NewGuid().ToString();

                if (imageFile != null && imageFile.Length > 0)
                {
                    var imageUrl = await _blobService.UploadFileAsync(imageFile.OpenReadStream(), imageFile.FileName);
                    product.ImageUrl = imageUrl;
                }

                await _productService.AddProductAsync(product);

                TempData["Message"] = "Product added successfully!";
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                TempData["Message"] = $"Error adding product: {ex.Message}";
                return View(product);
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(string id)
        {
            if (string.IsNullOrEmpty(id))
            {
                TempData["Message"] = "Invalid product ID.";
                return RedirectToAction(nameof(Index));
            }

            try
            {
                await _productService.DeleteProductAsync(id);
                TempData["Message"] = "Product deleted successfully!";
            }
            catch (Exception ex)
            {
                TempData["Message"] = $"Error deleting product: {ex.Message}";
            }

            return RedirectToAction(nameof(Index));
        }


    }
}
