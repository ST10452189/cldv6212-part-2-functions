﻿using Microsoft.AspNetCore.Mvc;
using ABC_Retail.Models;
using ABC_Retail.Azure;


namespace ABC_Retail.Controllers
{
    public class FilesController : Controller
    {
        private readonly FileShareService _fileService;

        public FilesController(IConfiguration config)
        {
            _fileService = new FileShareService(
                config["AzureStorage:ConnectionString"],
                config["AzureStorage:FileShare"]
            );
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Upload(IFormFile file)
        {
            if (file != null)
            {
                await _fileService.UploadFileAsync(file.FileName, file.OpenReadStream());
            }
            return RedirectToAction(nameof(Index));
        }
    }
}
