﻿using Azure;
using Azure.Data.Tables;
using System;
using System.ComponentModel.DataAnnotations;

namespace ABC_Retail.Models
{
    public class Customer : ITableEntity
    {
        public Customer()
        {
            PartitionKey = "Customer";
            RowKey = Guid.NewGuid().ToString(); 
        }

        public string PartitionKey { get; set; }
        public string RowKey { get; set; }

        [Required(ErrorMessage = "First name is required.")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Last name is required.")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "Email is required.")]
        [EmailAddress(ErrorMessage = "Invalid email address.")]
        public string Email { get; set; }

        public string Phone { get; set; }

        public ETag ETag { get; set; }
        public DateTimeOffset? Timestamp { get; set; }
    }
}
