using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;

var host = new HostBuilder()
    .ConfigureAppConfiguration((context, configBuilder) =>
    {
        var inMemorySettings = new Dictionary<string, string>
        {
            { "AzureWebJobsStorage", "DefaultEndpointsProtocol=https;AccountName=theosacc;AccountKey=694GKdgnRRG/ucgdgQKd7WZuxrJyZ9w+3Utez1UV13Uv76lB17jgVBV7Ca8iS0URpPlNLOlrRccx+AStTkJBOA==;EndpointSuffix=core.windows.net" },
            { "TableStorage", "Customers" }
        };

        configBuilder.AddInMemoryCollection(inMemorySettings);
    })
    .ConfigureFunctionsWorkerDefaults()
    .Build();

host.Run();
