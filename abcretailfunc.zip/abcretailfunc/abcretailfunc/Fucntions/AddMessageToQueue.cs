﻿using System;
using System.IO;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Azure.Storage.Queues;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;

namespace abcretailfunc.Fucntions
{
    public class AddMessageToQueue
    {
        private readonly ILogger _logger;
        public AddMessageToQueue(ILoggerFactory loggerFactory)
            => _logger = loggerFactory.CreateLogger<AddMessageToQueue>();

        [Function("AddMessageToQueue")]
        public async Task<HttpResponseData> Run(
            [HttpTrigger(AuthorizationLevel.Function, "post", Route = "queue")] HttpRequestData req)
        {
            _logger.LogInformation("Processing AddMessageToQueue request...");

            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            if (string.IsNullOrWhiteSpace(requestBody))
            {
                var badResponse = req.CreateResponse(System.Net.HttpStatusCode.BadRequest);
                await badResponse.WriteStringAsync("Request body is empty.");
                return badResponse;
            }

            object message;
            try
            {
                message = JsonSerializer.Deserialize<object>(requestBody);
            }
            catch (JsonException ex)
            {
                _logger.LogError(ex, "Invalid JSON format.");
                var badResponse = req.CreateResponse(System.Net.HttpStatusCode.BadRequest);
                await badResponse.WriteStringAsync("Invalid JSON format.");
                return badResponse;
            }

            var connectionString = Environment.GetEnvironmentVariable("AzureWebJobsStorage");
            if (string.IsNullOrEmpty(connectionString))
            {
                throw new Exception("Storage connection string is missing.");
            }

            var queueName = Environment.GetEnvironmentVariable("QueueName") ?? "orders";
            var queueClient = new QueueClient(connectionString, queueName);
            await queueClient.CreateIfNotExistsAsync();

            string msg = JsonSerializer.Serialize(message);
            string encodedMessage = Convert.ToBase64String(Encoding.UTF8.GetBytes(msg));
            await queueClient.SendMessageAsync(encodedMessage);

            var response = req.CreateResponse(System.Net.HttpStatusCode.OK);
            await response.WriteStringAsync("Message added to queue successfully.");
            return response;
        }
    }
}
