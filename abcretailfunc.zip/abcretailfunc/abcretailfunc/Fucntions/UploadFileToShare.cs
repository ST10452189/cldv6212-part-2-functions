﻿using System;
using System.IO;
using System.Threading.Tasks;
using Azure.Storage.Files.Shares;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;

namespace abcretailfunc.Fucntions
{
    public class DownloadFileFromShare
    {
        private readonly ILogger _logger;

        public DownloadFileFromShare(ILoggerFactory loggerFactory) =>
            _logger = loggerFactory.CreateLogger<DownloadFileFromShare>();

        [Function("DownloadFileFromShare")]
        public async Task<HttpResponseData> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", Route = "fileshare/{fileName}")] HttpRequestData req,
            string fileName)
        {
            _logger.LogInformation($"Processing request to download file: {fileName}");

            if (string.IsNullOrWhiteSpace(fileName))
            {
                var badResponse = req.CreateResponse(System.Net.HttpStatusCode.BadRequest);
                await badResponse.WriteStringAsync("File name is required.");
                return badResponse;
            }

            var connectionString = Environment.GetEnvironmentVariable("AzureWebJobsStorage");
            if (string.IsNullOrEmpty(connectionString))
                throw new Exception("Storage connection string is missing.");

            var shareName = Environment.GetEnvironmentVariable("FileShareName") ?? "theosfiles";
            var shareClient = new ShareClient(connectionString, shareName);
            var directory = shareClient.GetRootDirectoryClient();
            var fileClient = directory.GetFileClient(fileName);

            if (!await fileClient.ExistsAsync())
            {
                var notFoundResponse = req.CreateResponse(System.Net.HttpStatusCode.NotFound);
                await notFoundResponse.WriteStringAsync($"File '{fileName}' not found.");
                return notFoundResponse;
            }

            var downloadInfo = await fileClient.DownloadAsync();
            var stream = new MemoryStream();
            await downloadInfo.Value.Content.CopyToAsync(stream);
            stream.Position = 0;

            var response = req.CreateResponse(System.Net.HttpStatusCode.OK);
            response.Headers.Add("Content-Type", "application/octet-stream");
            response.Headers.Add("Content-Disposition", $"attachment; filename=\"{fileName}\"");
            await response.WriteBytesAsync(stream.ToArray());

            return response;
        }
    }
}
