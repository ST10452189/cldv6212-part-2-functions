using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text.Json;
using System.Threading.Tasks;
using abcretailfunc.Models;
using Azure;
using Azure.Data.Tables;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace abcretailfunc.Fucntions
{
    public class CustomerFunctions
    {
        private readonly ILogger _logger;
        private readonly string _connectionString;
        private readonly string _tableName;

        public CustomerFunctions(ILoggerFactory loggerFactory, IConfiguration configuration)
        {
            _logger = loggerFactory.CreateLogger<CustomerFunctions>();
            _connectionString = configuration["AzureWebJobsStorage"];
            _tableName = configuration["TableStorage"] ?? "Customers";
        }

        // POST: Add customer
        [Function("AddCustomerToTable")]
        public async Task<HttpResponseData> AddCustomer(
            [HttpTrigger(AuthorizationLevel.Function, "post", Route = "customer")] HttpRequestData req)
        {
            try
            {
                _logger.LogInformation("Processing AddCustomerToTable request...");

                string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
                if (string.IsNullOrWhiteSpace(requestBody))
                    throw new ArgumentException("Request body is empty.");

                var customer = JsonSerializer.Deserialize<Customer>(requestBody);
                if (customer == null)
                    throw new ArgumentException("Invalid JSON format for customer.");

                if (string.IsNullOrWhiteSpace(customer.FirstName) || string.IsNullOrWhiteSpace(customer.LastName))
                    throw new ArgumentException("FirstName and LastName are required fields.");

                if (string.IsNullOrWhiteSpace(customer.PartitionKey))
                    customer.PartitionKey = "Customer";
                if (string.IsNullOrWhiteSpace(customer.RowKey))
                    customer.RowKey = Guid.NewGuid().ToString();

                var tableClient = new TableClient(_connectionString, _tableName);
                await tableClient.CreateIfNotExistsAsync();
                await tableClient.AddEntityAsync(customer);

                var response = req.CreateResponse(HttpStatusCode.OK);
                await response.WriteStringAsync($"Customer {customer.FirstName} {customer.LastName} added successfully.");
                return response;
            }
            catch (ArgumentException ex)
            {
                _logger.LogError(ex, "Invalid input.");
                var response = req.CreateResponse(HttpStatusCode.BadRequest);
                await response.WriteStringAsync($"Input Error: {ex.Message}");
                return response;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unexpected error.");
                var response = req.CreateResponse(HttpStatusCode.InternalServerError);
                await response.WriteStringAsync($"Server Error: {ex.Message}");
                return response;
            }
        }

        // GET: Get customers
        [Function("GetCustomersFromTable")]
        public async Task<HttpResponseData> GetCustomers(
            [HttpTrigger(AuthorizationLevel.Function, "get", Route = "customer")] HttpRequestData req)
        {
            _logger.LogInformation("Processing GetCustomersFromTable request...");

            try
            {
                var tableClient = new TableClient(_connectionString, _tableName);

                var customers = new List<Customer>();
                await foreach (var entity in tableClient.QueryAsync<Customer>())
                    customers.Add(entity);

                var response = req.CreateResponse(HttpStatusCode.OK);
                response.Headers.Add("Content-Type", "application/json");
                await response.WriteStringAsync(JsonSerializer.Serialize(customers));
                return response;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving customers from table storage.");
                var response = req.CreateResponse(HttpStatusCode.InternalServerError);
                await response.WriteStringAsync($"Server Error: {ex.Message}");
                return response;
            }
        }

        // DELETE: Delete customer
        [Function("DeleteCustomerFromTable")]
        public async Task<HttpResponseData> DeleteCustomer(
            [HttpTrigger(AuthorizationLevel.Function, "delete", Route = "customer/{rowKey}")] HttpRequestData req,
            string rowKey)
        {
            try
            {
                _logger.LogInformation($"Processing DeleteCustomer request for RowKey: {rowKey}");

                if (string.IsNullOrWhiteSpace(rowKey))
                    throw new ArgumentException("RowKey is required.");

                var tableClient = new TableClient(_connectionString, _tableName);

                await tableClient.DeleteEntityAsync("Customer", rowKey);

                var response = req.CreateResponse(HttpStatusCode.OK);
                await response.WriteStringAsync($"Customer with RowKey {rowKey} deleted successfully.");
                return response;
            }
            catch (RequestFailedException ex) when (ex.Status == 404)
            {
                var response = req.CreateResponse(HttpStatusCode.NotFound);
                await response.WriteStringAsync($"Customer with RowKey {rowKey} not found.");
                return response;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deleting customer.");
                var response = req.CreateResponse(HttpStatusCode.InternalServerError);
                await response.WriteStringAsync($"Server Error: {ex.Message}");
                return response;
            }
        }
    }
}
