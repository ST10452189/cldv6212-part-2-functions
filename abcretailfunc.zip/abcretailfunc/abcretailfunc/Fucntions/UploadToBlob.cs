﻿using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Azure.Storage.Sas;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace abcretailfunc.Functions
{
    public class BlobFunctions
    {
        private readonly ILogger<BlobFunctions> _logger;
        private readonly BlobServiceClient _blobClient;
        private readonly string _containerName;

        public BlobFunctions(IConfiguration configuration, ILogger<BlobFunctions> logger)
        {
            _logger = logger;
            _blobClient = new BlobServiceClient(configuration["AzureStorage:ConnectionString"]);
            _containerName = configuration["AzureStorage:BlobContainer"];
        }

        [Function("UploadBlob")]
        public async Task<HttpResponseData> UploadBlob([HttpTrigger(AuthorizationLevel.Anonymous, "post")] HttpRequestData req)
        {
            try
            {
                string fileName = req.Headers.TryGetValues("x-file-name", out var values) ? values.FirstOrDefault() : null;
                if (string.IsNullOrEmpty(fileName))
                {
                    var badRequest = req.CreateResponse(HttpStatusCode.BadRequest);
                    await badRequest.WriteAsJsonAsync(new { message = "File name required in x-file-name header" });
                    return badRequest;
                }

                using var memoryStream = new MemoryStream();
                await req.Body.CopyToAsync(memoryStream);
                memoryStream.Position = 0;

                var container = _blobClient.GetBlobContainerClient(_containerName);
                await container.CreateIfNotExistsAsync(PublicAccessType.None);

                var blob = container.GetBlobClient(fileName);
                await blob.UploadAsync(memoryStream, overwrite: true);

                var sasBuilder = new BlobSasBuilder
                {
                    BlobContainerName = _containerName,
                    BlobName = blob.Name,
                    ExpiresOn = DateTimeOffset.UtcNow.AddYears(1)
                };
                sasBuilder.SetPermissions(BlobSasPermissions.Read);
                var fileUrl = $"{blob.Uri}?{blob.GenerateSasUri(sasBuilder).Query}";

                var response = req.CreateResponse(HttpStatusCode.OK);
                await response.WriteAsJsonAsync(new { message = "File uploaded successfully", url = fileUrl });
                return response;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error uploading file to blob");
                var errorResponse = req.CreateResponse(HttpStatusCode.InternalServerError);
                await errorResponse.WriteAsJsonAsync(new { message = "Error uploading file", error = ex.Message });
                return errorResponse;
            }
        }

        [Function("DeleteBlob")]
        public async Task<HttpResponseData> DeleteBlob([HttpTrigger(AuthorizationLevel.Anonymous, "delete")] HttpRequestData req)
        {
            try
            {
                var body = await req.ReadFromJsonAsync<dynamic>();
                string fileUrl = body?.fileUrl;

                if (string.IsNullOrEmpty(fileUrl))
                {
                    var badRequest = req.CreateResponse(HttpStatusCode.BadRequest);
                    await badRequest.WriteAsJsonAsync(new { message = "File URL is required" });
                    return badRequest;
                }

                var uri = new Uri(fileUrl);
                var fileName = Path.GetFileName(uri.LocalPath);

                var container = _blobClient.GetBlobContainerClient(_containerName);
                var blob = container.GetBlobClient(fileName);
                await blob.DeleteIfExistsAsync();

                var response = req.CreateResponse(HttpStatusCode.OK);
                await response.WriteAsJsonAsync(new { message = "File deleted successfully" });
                return response;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deleting file from blob");
                var errorResponse = req.CreateResponse(HttpStatusCode.InternalServerError);
                await errorResponse.WriteAsJsonAsync(new { message = "Error deleting file", error = ex.Message });
                return errorResponse;
            }
        }
    }
}
